/* ==========================================================================
   LOOM & LIGHT — NAVBAR JS
   Standalone navbar behavior: theme toggle, RTL toggle, dropdown, mobile
   menu, active link, header scroll state.

   NOTE: these same behaviors already live inside global.js (initTheme,
   initDirection, initNavDropdown, initMobileMenu, initActiveLink,
   initHeaderScroll). Use ONE or the other on a page — loading both
   global.js and navbar.js together will bind duplicate listeners.
   Keep this file if you want the navbar to be a fully self-contained
   drop-in component independent of global.js.
   ========================================================================== */

(function () {
  'use strict';

  var STORAGE_THEME = 'll-theme';
  var STORAGE_DIR = 'll-dir';
  var root = document.documentElement;

  /* Theme ---------------------------------------------------------------- */
  function initTheme() {
    var saved = localStorage.getItem(STORAGE_THEME);
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    applyTheme(saved || (prefersDark ? 'dark' : 'light'));

    document.querySelectorAll('[data-theme-toggle]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', root.getAttribute('data-theme') === 'dark');
      btn.addEventListener('click', function () {
        var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(next);
        localStorage.setItem(STORAGE_THEME, next);
        document.querySelectorAll('[data-theme-toggle]').forEach(function (b) {
          b.setAttribute('aria-pressed', next === 'dark');
        });
      });
    });
  }

  function applyTheme(theme) {
    theme === 'dark' ? root.setAttribute('data-theme', 'dark') : root.removeAttribute('data-theme');
  }

  /* RTL -------------------------------------------------------------------- */
  function initDirection() {
    var saved = localStorage.getItem(STORAGE_DIR) || 'ltr';
    root.setAttribute('dir', saved);

    document.querySelectorAll('[data-rtl-toggle]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', saved === 'rtl');
      btn.addEventListener('click', function () {
        var next = root.getAttribute('dir') === 'rtl' ? 'ltr' : 'rtl';
        root.setAttribute('dir', next);
        localStorage.setItem(STORAGE_DIR, next);
        document.querySelectorAll('[data-rtl-toggle]').forEach(function (b) {
          b.setAttribute('aria-pressed', next === 'rtl');
        });
      });
    });
  }

  /* Desktop dropdown (Home ▾) — grace-period close ------------------------- */
  function initNavDropdown() {
    var CLOSE_DELAY = 350;
    var dropdowns = document.querySelectorAll('.nav-dropdown');

    dropdowns.forEach(function (dropdown) {
      var closeTimer = null;
      var trigger = dropdown.querySelector('.nav-dropdown-trigger');
      if (!trigger) return;

      function open() {
        clearTimeout(closeTimer);
        dropdown.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
      }

      function scheduleClose() {
        clearTimeout(closeTimer);
        closeTimer = setTimeout(function () {
          dropdown.classList.remove('is-open');
          trigger.setAttribute('aria-expanded', 'false');
        }, CLOSE_DELAY);
      }

      dropdown.addEventListener('mouseenter', open);
      dropdown.addEventListener('mouseleave', scheduleClose);
      dropdown.addEventListener('focusin', open);
      dropdown.addEventListener('focusout', scheduleClose);
      trigger.addEventListener('click', function (e) {
        e.preventDefault();
        dropdown.classList.contains('is-open') ? scheduleClose() : open();
      });
    });

    document.addEventListener('click', function (e) {
      dropdowns.forEach(function (dropdown) {
        if (!dropdown.contains(e.target)) {
          dropdown.classList.remove('is-open');
          var t = dropdown.querySelector('.nav-dropdown-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  /* Mobile menu -------------------------------------------------------------- */
  function initMobileMenu() {
    var toggle = document.querySelector('[data-mobile-menu-toggle]');
    var menu = document.querySelector('[data-mobile-menu]');
    var backdrop = document.querySelector('[data-mobile-menu-backdrop]');
    if (!toggle || !menu) return;

    function close() {
      menu.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('mobile-menu-active');
    }

    function open() {
      menu.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      document.body.classList.add('mobile-menu-active');
    }

    toggle.addEventListener('click', function () {
      menu.classList.contains('is-open') ? close() : open();
    });

    if (backdrop) backdrop.addEventListener('click', close);
    menu.querySelectorAll('a').forEach(function (link) { link.addEventListener('click', close); });
    window.addEventListener('resize', function () { if (window.innerWidth > 991) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  /* Active link -------------------------------------------------------------- */
  function initActiveLink() {
    var current = window.location.pathname.split('/').pop() || 'home-1.html';
    document.querySelectorAll('.nav-item, .mobile-nav-item, .nav-dropdown-link').forEach(function (link) {
      var href = (link.getAttribute('href') || '').split('/').pop();
      if (href === current) {
        link.classList.add('is-active');
        link.setAttribute('aria-current', 'page');
      }
    });
  }

  /* Header scroll state -------------------------------------------------------- */
  function initHeaderScroll() {
    var header = document.querySelector('[data-site-header]');
    if (!header) return;
    function update() { header.classList.toggle('is-scrolled', window.scrollY > 12); }
    update();
    window.addEventListener('scroll', update, { passive: true });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initDirection();
    initNavDropdown();
    initMobileMenu();
    initActiveLink();
    initHeaderScroll();
  });
})();
