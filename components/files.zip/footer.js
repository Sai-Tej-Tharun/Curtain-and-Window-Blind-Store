/* ==========================================================================
   LOOM & LIGHT — FOOTER JS
   Current-year injection + newsletter form feedback (no redirect/reload).

   NOTE: form feedback here duplicates initFormFeedback() in global.js.
   Use ONE of the two on a given page to avoid double-binding the submit
   handler on [data-ajax-form].
   ========================================================================== */

(function () {
  'use strict';

  function setCurrentYear() {
    var year = new Date().getFullYear();
    document.querySelectorAll('[data-current-year]').forEach(function (el) {
      el.textContent = year;
    });
  }

  function initNewsletterForm() {
    document.querySelectorAll('[data-ajax-form]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var feedback = form.querySelector('[data-form-feedback]');
        var emailInput = form.querySelector('input[type="email"]');

        if (emailInput && !emailInput.checkValidity()) {
          emailInput.reportValidity();
          return;
        }

        if (feedback) {
          feedback.textContent = form.getAttribute('data-success-message') || 'Thank you!';
          feedback.classList.add('is-visible');
        }
        form.reset();
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    setCurrentYear();
    initNewsletterForm();
  });
})();
